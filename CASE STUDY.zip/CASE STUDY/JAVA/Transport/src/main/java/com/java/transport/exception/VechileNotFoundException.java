package com.java.transport.exception;

public class VechileNotFoundException extends Exception{
	public VechileNotFoundException(String comment)
	{
		super(comment);
	}
}
