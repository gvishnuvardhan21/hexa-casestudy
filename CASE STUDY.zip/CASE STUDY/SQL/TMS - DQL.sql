select * from vehicles;

select * from routes;

select * from trips;

select * from passengers;

select * from bookings;

select * from driver;